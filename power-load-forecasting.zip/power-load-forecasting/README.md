# Power Load Forecasting & Data Annotation Pipeline

A portfolio implementation of a time-series data-quality and ML forecasting workflow inspired by my Data & ML work in the power domain.

> This repository uses synthetic/public-style data and does **not** contain confidential government datasets.

## What it demonstrates
- Time-series dataset validation
- Missing-value handling and duplicate detection
- Rule-based labeling of consumption patterns
- Feature engineering with lag and rolling-window features
- Random Forest regression for load forecasting
- Evaluation using MAE, RMSE and R²
- Reproducible Python workflow

## Run
```bash
pip install -r requirements.txt
python src/generate_data.py
python src/pipeline.py
```

## Tech
Python, Pandas, NumPy, scikit-learn, Matplotlib
