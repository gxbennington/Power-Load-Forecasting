from pathlib import Path
import numpy as np
import pandas as pd

rng = np.random.default_rng(42)
n = 24 * 180
ts = pd.date_range("2025-01-01", periods=n, freq="h")
hour = ts.hour.to_numpy()
dow = ts.dayofweek.to_numpy()

base = 420 + 80*np.sin((hour-7)*np.pi/12) + 35*(dow < 5)
trend = np.linspace(0, 30, n)
noise = rng.normal(0, 18, n)
load = np.maximum(base + trend + noise, 50)

df = pd.DataFrame({"timestamp": ts, "load_mw": load})
# Introduce realistic data-quality issues for the pipeline to detect.
df.loc[rng.choice(n, 25, replace=False), "load_mw"] = np.nan
df = pd.concat([df, df.iloc[[100, 100]]], ignore_index=True)

Path("data").mkdir(exist_ok=True)
df.to_csv("data/raw_load.csv", index=False)
print("Created data/raw_load.csv")
