from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

raw = pd.read_csv("data/raw_load.csv", parse_dates=["timestamp"])
raw = raw.drop_duplicates(subset=["timestamp"]).sort_values("timestamp")

# Data validation / cleaning
raw["load_mw"] = raw["load_mw"].interpolate(limit_direction="both")
raw = raw[(raw["load_mw"] > 0) & (raw["load_mw"] < 2000)].copy()

# Annotation taxonomy: Low / Normal / Peak consumption
q1, q2 = raw["load_mw"].quantile([0.33, 0.66])
raw["load_label"] = np.select(
    [raw["load_mw"] <= q1, raw["load_mw"] >= q2],
    ["LOW", "PEAK"],
    default="NORMAL"
)

# Time-series features
raw["hour"] = raw["timestamp"].dt.hour
raw["dayofweek"] = raw["timestamp"].dt.dayofweek
raw["lag_1h"] = raw["load_mw"].shift(1)
raw["lag_24h"] = raw["load_mw"].shift(24)
raw["rolling_24h"] = raw["load_mw"].rolling(24).mean()
raw = raw.dropna().reset_index(drop=True)

features = ["hour", "dayofweek", "lag_1h", "lag_24h", "rolling_24h"]
split = int(len(raw) * 0.8)
X_train, X_test = raw.loc[:split-1, features], raw.loc[split:, features]
y_train, y_test = raw.loc[:split-1, "load_mw"], raw.loc[split:, "load_mw"]

model = RandomForestRegressor(n_estimators=250, random_state=42, n_jobs=-1)
model.fit(X_train, y_train)
pred = model.predict(X_test)

rmse = mean_squared_error(y_test, pred) ** 0.5
print(f"MAE : {mean_absolute_error(y_test, pred):.2f} MW")
print(f"RMSE: {rmse:.2f} MW")
print(f"R²  : {r2_score(y_test, pred):.3f}")

Path("outputs").mkdir(exist_ok=True)
raw.to_csv("outputs/annotated_load_dataset.csv", index=False)

# Plot actual vs predicted load for the test period
plt.figure(figsize=(10, 5))
plt.plot(y_test.values[:200], label="Actual", linewidth=1.5)
plt.plot(pred[:200], label="Predicted", linewidth=1.5, alpha=0.8)
plt.xlabel("Time step (test set)")
plt.ylabel("Load (MW)")
plt.title("Power Load Forecasting: Actual vs Predicted")
plt.legend()
plt.tight_layout()
plt.savefig("outputs/actual_vs_predicted.png", dpi=150)
print("Plot saved to outputs/actual_vs_predicted.png")
